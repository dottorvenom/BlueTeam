#!/bin/sh
curl  -o wazuh-agent-ubuntu.deb http://10.10.255.199/wazuh-agent-ubuntu.deb > wlog.txt

sudo WAZUH_MANAGER='brutal.wheelie.network' dpkg -i ./wazuh-agent-ubuntu.deb >> wlog.txt


systemctl daemon-reload
systemctl enable wazuh-agent
systemctl start wazuh-agent



#----- copiare ossenc.conf  sostituiendo il MANAGER_IP   <-------  da apache

#prevedere l'invio del wlog.txt con curl POST su apache




#service wazuh-agent restart >> wlog.txt

#/var/ossec/bin/agent-auth -m brutal.wheelie.network >> wlog.txt

#cp /var/ossec/etc/local_internal_options.conf /var/ossec/etc/local_internal_options.bak
#echo wazuh_command.remote_commands=1 >> /var/ossec/etc/local_internal_options.conf >> wlog.txt

#service wazuh-agent restart >> wlog.txt