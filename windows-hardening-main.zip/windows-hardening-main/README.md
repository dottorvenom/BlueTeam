# windows-hardening

Repo di riferimento per il team Hardening-Windows.

Da utilizzare per accentrare informazioni, stati Salt, e script powershell. 

Seguire gli esempi per scrivere State file (sls) ed aggiungerli alla cartella /salt.

## Info

[Quali attacchi potremmo vedere?](https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Methodology%20and%20Resources/Active%20Directory%20Attack.md)

[Awesome Windows Domain Hardening](https://github.com/PaulSec/awesome-windows-domain-hardening)

[ansible-hardening-windows](https://github.com/juju4/ansible-harden-windows)