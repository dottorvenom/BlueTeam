Public Class Class1

End Class

Public Class datafile
    Public ip As String
    Public port As Integer
    Public username As String
    Public password_old As String
    Public password_new As String
    Public salt_master As String

End Class