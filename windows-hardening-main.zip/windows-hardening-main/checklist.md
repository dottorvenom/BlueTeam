- [X] Protezione Lsass
- [X] Check Windows Defender e regole ASR
- [X] Delete shadow copy
- [X] Disabilitato:
		
		Powershell V2, Printer driver download, Printing over HTTP, ICMP Redirect, DNS Multicast, Multi homed resolution, stored credentials, AlwaysInstallElevated

- [X] Abilitato:
		
		UAC, Always notify, Safe DLL loading, explorer DEP, explorer SPP, SMBSigning

- [ ] Powershell logging: cosa abilitare? (chiedere a TH)

- [ ] Per familiarizzazione:

		Verificare livello patching
		Identificiare Security Update necessari e download KB
		Applicare patch

- [X] Disabilitare Administrator locali e Guest Account

- [X] Do not allow storage of passwords and credentials for network authentication
	 ```
	 $networkaccess = Get-ItemProperty -Path "Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Lsa\" -Name disabledomaincreds -ErrorAction SilentlyContinue|Select-Object -ExpandProperty disabledomaincreds
	 ```
- [X] rotazione krbtgt 2 volte - golden ticket

- [X] Applica Constrained Language Mode

- [ ] Deploy LAPS (?)

- [X] block kerberos relay attacks   -> applicare a stato del DC
```
	Get-ADObject -Identity ((Get-ADDomain).distinguishedname) -Properties 'ms-DS-MachineAccountQuota'
	Get-ADDomain | Get-ADObject -Properties 'ms-DS-MachineAccountQuota'
	Set-ADDomain -Identity <DomainName> -Replace @{"ms-DS-MachineAccountQuota"="0"}
```
- [X] verifica file di sistema windows

- [ ] SE SERVE: Quali path devono essere esclusi dal defender?

- [ ] set powershell all signed -> con script!

- [ ] Controllo share

- [ ] Controllo in sysvol e gpo (script e password)

- [ ] Verifica e disabilitazione task schedulati

- [ ] Controllo AdminSDHolder

- [ ] verifica exploit printernightmare  sam nightmare  rogue ejuicy potato  ms17 eternal blue zerologon

- [X] verifica null session

- [ ] patch rdp (?)

- [ ] verifica unquoted path

- [ ] verifica privilegi utenti admin, spn, pre-auth kerberos
	```
	SeImpersonate and SeAssignPrimaryToken
	SeDebugPrivilege
	SeTakeOwnershipPrivilege
	- [ ] Check di account con SPN impostato -> DEVONO avere password +25char
	- [ ] Disabilitare "Do not require pre-auth" per gli account di dominio! 
	- [ ] Definire gli utenti che andranno nel gruppo "Domain protected user"

	```

- [X] verifica smb version

- [ ] verifica registro voci run

- [ ] verifica netstat

- [ ] gpo abilita full audit	

- [ ] controllo SID history

- [ ] controllo dll con process explorer per hijacking (?)

- [ ] Resource based Constrained Delegation:
```powershell
#Applicare solo a computer account
Set-ADComputer COMPUTER -PrincipalsAllowedToDelegateToAccount $Null
```