Un esempio di cosa e come implementare in salt.

Disabilitare account administrator locale:
```yaml
localuser.disable.administrator:
  cmd.run:
    - name: "Get-LocalUser Administrator | Disable-LocalUser"
    - shell: powershell
    - onlyif: powershell -command "if ((Get-LocalUser | Where-Object {($_.Name -eq 'Administrator') -and ($_.Enabled -eq $true)}) -eq $null) {exit 1}"
```

Abilitare funzioni avanzate di sicurezza:
```yaml
allow_processmitigation:
  cmd.run:
    - name: "Set-ProcessMitigation -System -Enable (CHECK SU COSA ABILITARE LIVELLO SISTEMA)"
    - shell: powershell
```

Check ed eliminazione chiave di registro windows:
```yaml
'HKEY_CURRENT_USER\\SOFTWARE\\BLABLA':
  reg.absent
    - vname: version  -> valuename, quindi NON DEVE ESISTERE un valuename version per quella chiave
```

Stessa cosa si applica per le chiavi:
```yaml
remove_key_test:
  reg.key_absent:
    - name: HKEY_NOME_CHIAVE_PER_INTERO
```

Definire la presenza di una chiave di registro:
```yaml
HKEY_CURRENT\\SOFTWARE\\TEST:
  reg.present:
    - vname: version
    - vdata: test.1.0
```
Disabilitare RDP:

```yaml
disable_rdp:
  module.run
    - name: rdp.disable
```

Lanciare un comando se succede qualcosa:

```yaml
comando.condizionato:
  cmd.run:
    - name: "Get-FaiQualcosa"
    - shell: powershell
    - onlyif: powershell -command "if ((Get-LocalUser | Where-Object {($_.Name -eq 'Administrator') -and ($_.Enabled -eq $true)}) -eq $null) {exit 1}"
```
