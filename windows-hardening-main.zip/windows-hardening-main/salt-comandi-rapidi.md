Interazione con servizi:
```yaml
salt "*" service.disable <service-name>
salt "*" service.info spooler
salt "*" service.modify spooler start_type=disabled
```

Installare patch, _available_ per listare updates disponibili - _install_ per installare.
```yaml
salt "*" win_wua.available
salt "*" win_wua.available categories=["Security Updates"] severities=["Critical"]

salt "*" win_wua.install KBXXXXXX
```

Interagire e/o definire GPO:
```yaml
# ottieni tutte le gpo, classe machine
salt '*' lgpo.get machine return_full_policy_names=True

# definisci gpo con dict
salt '*' lgpo.set computer_policy="{'LockoutDuration': 2, 'RestrictAnonymous': 'Enabled', 'AuditProcessTracking': 'Succes, Failure'}"

# definisci con path o diretta
salt '*' lgpo.set_user_policy "Control Panel\Display\Disable the Display Control Panel" Enabled

salt '*' lgpo.set_computer_policy LockoutDuration 1440

```
