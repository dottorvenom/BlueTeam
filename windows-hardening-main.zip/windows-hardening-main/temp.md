Cosa fare nell'hardening?

- [ ] Powershell Logging: Abilitare ScriptBlock (chiave di registro?)
- [X] Applicare regole ASR per limitare capacità di azione su processi
- [ ] Applocker?
- [ ] Verificare patching ogni macchina
- [ ] Deploy LAPS e rimuovi account admin locali
- [ ] Deploy di update via KB su master nodes (PrinterNightmare, ZeroLogon, samAccountName spoofing)
- [X] Applica constrained language mode

## AD SPECIFIC HARDENING
Resource based Constrained Delegation:
```powershell
#Applicare solo a computer account
Set-ADComputer COMPUTER -PrincipalsAllowedToDelegateToAccount $Null
```
- [ ] Check di account con SPN impostato -> DEVONO avere password +25char
- [ ] Disabilitare "Do not require pre-auth" per gli account di dominio! 
- [ ] Definire gli utenti che andranno nel gruppo "Domain protected user"


## SALT STATE
```yaml
{% set filetype = ['htafile','wshfile','wsffile','batfile','jsfile','jsefile','vbefile','vbsfile'] %}
restore_file_association:
  {% for type in filetype %}
  cmd.run:
    - name: "ftype {{ type }}='%SystemRoot%\system32\NOTEPAD.EXE' '%1'"

disable_administrator:
  cmd.run:
    - name: "Get-LocalUser Administrator | Disable-LocalUser"
    - shell: powershell
    - onlyif: powershell -command "if ((Get-LocalUser | Where-Object {($_.Name -eq 'Administrator') -and ($_.Enabled -eq $true)}) -eq $null) {exit 1}"

########## verificare
resolve_unquothed_path:
  cmd.script:
    - name: salt://powershell/windows_path_enumerate.ps1
    - shell: powershell
    - onlyif: powershell -command "wmic service get name,displayname,pathname,startmode |findstr /i "auto" |findstr /i /v "c:\windows\\" |findstr /i /v '"'"
##############

enable_scriptblock_logging:
  reg.present:
    - name: 'HKLM\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging'
    - vname: EnableScriptBlockLogging
    - vdata: 1



{% set officekey = [{'key':'HKCU\Software\Microsoft\Office\14.0\Word\Options','value':'DontUpdateLinks','type':'REG_DWORD','data':'00000001'},{'key':'HKCU\Software\Microsoft\Office\14.0\Word\Options\WordMail','value':'DontUpdateLinks','type':'REG_DWORD','data':'00000001'},{'key':'HKCU\Software\Microsoft\Office\15.0\Word\Options','value':'DontUpdateLinks','type':'REG_DWORD','data':'00000001'},{'key':'HKCU\Software\Microsoft\Office\15.0\Word\Options\WordMail','value':'DontUpdateLinks','type':'REG_DWORD','data':'00000001'},{'key':'HKCU\Software\Microsoft\Office\16.0\Word\Options','value':'DontUpdateLinks','type':'REG_DWORD','data':'00000001'},{'key':'HKCU\Software\Microsoft\Office\16.0\Word\Options\WordMail','value':'DontUpdateLinks','type':'REG_DWORD','data':'00000001'}] %}

msoffice_hardening:
  {% for k in officekey %}
  reg.present:
    - name: {{ k['key'] }}
    - vname: {{ k['value'] }}
    - vdata: {{ k['data'] }}
    - vtype: {{ k['type'] }}
  {% endfor %}

  ```